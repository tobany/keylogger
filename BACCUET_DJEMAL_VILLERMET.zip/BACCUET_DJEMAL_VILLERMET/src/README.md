# keylogger
Small keylogger project with light client and server
