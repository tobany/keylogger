------------------- BACCUET Anthony ---- DJEMAL Bilal ---- VILLERMET Quentin -------------------
/!\ Il est conseillé de lire le rapport (présent dans ./doc/rapport.pdf) avant de continuer /!\

Si votre ordinateur dispose d'un antivirus (y compris Windows Defender) :
 Il se peut qu'un ou plusieurs des fichiers malveillants dans le dossier 'payload' soit mis en quarantaine.

Pour faire fonctionnner notre keylogger, il faut commencer par installer un serveur FTP et un serveur MySQl.
Le serveur FTP doit pouvoir être accessible depuis tout les postes qui seront infecté par le keylogger. 
Il faut modifier dans le fichier ServerFTP les variable SERVER, USERNAME et PASSWORD pour qu'elles correspondent aux informations de connexion du serveur FTP.
Pour la partie visualisation, il faut pouvoir accéder à un serveur MySQL pour lire et analyser les données, et au serveur FTP pour les récupérer. Les informations de connexion seront demandé lors de l'exécution.

Description de l'arborescence :
|_ bin - contient les .exe d'exécution de MyKeyLogger (partie malware) et mykeyloggerviewer (partie visualisation)
|_ doc - contient le compte-rendu final du projet sous format pdf
|_ payload - contient les différents déploiements (dissimulation comme fausse image, tentatives d'embedding pdf)
|_ src - contient le code source complet des deux applications du projet

Le fichier .exe de la partie visualisation du keylogger est contenue dans le dossier 'netcoreapp3.1' (keyloggerviewer.exe).
Cela est dû aux fichiers .dll nécéssairement inclus pour son bon fonctionnement à l'heure actuelle.

Détails :
'payload' est divisé en sous-dossiers -- 
	'Hidden extension', 'scr' et 'Unitrix' pour les payloads images,
	'pdf_tests' avec les tentatives de dissimulation au sein d'un pdf
	'img' avec les images de base ayant servi à la dissimulation
	le fichier 'svcshot.exe' qui est un exemple de payload semi-dissimulé mimiquant un programme système.

Tous ces éléments sont détaillés dans le rapport, ainsi que dans la vidéo explicative bonus :
https://www.youtube.com/watch?v=ZPuKVvODkgg

Les fonctionnalités principales des deux applications sont présentées dans la vidéo explicative principale :
https://www.youtube.com/watch?v=Jiij8g7Y7v4

En cas de souci de fonctionnement, n'hésitez pas à nous contacter sur nos adresses universitaires.